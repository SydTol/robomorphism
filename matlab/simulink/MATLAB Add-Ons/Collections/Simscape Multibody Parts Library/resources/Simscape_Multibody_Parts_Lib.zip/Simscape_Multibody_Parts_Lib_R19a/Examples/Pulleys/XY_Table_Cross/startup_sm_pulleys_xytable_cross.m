addpath(pwd)
addpath([pwd filesep 'Images']);
addpath([pwd filesep 'Scripts_Data']);

load sm_pulleys_xytable_cross_driveqs

sm_pulleys_xytable_cross

% Copyright 2012-2019 The MathWorks, Inc.
