% Copyright 2017-2019 The MathWorks, Inc.

addpath(pwd)
addpath([pwd filesep 'CAD']);
addpath([pwd filesep 'Libraries']);
addpath([pwd filesep 'Scripts_Data']);
addpath([pwd filesep 'html' filesep 'html']);

xts_PARAM

xts_system
