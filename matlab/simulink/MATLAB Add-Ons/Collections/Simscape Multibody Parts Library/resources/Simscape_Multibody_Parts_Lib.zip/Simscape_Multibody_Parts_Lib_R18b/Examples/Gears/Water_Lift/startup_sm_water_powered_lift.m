% Startup script for sm_water_powered_lift.slx
% Copyright 2017-2018 The MathWorks, Inc.

addpath(pwd);
addpath([pwd filesep 'Images']);
addpath([pwd filesep 'Scripts_Data']);
addpath([pwd filesep 'html' filesep 'html']);

sm_water_powered_lift_param

sm_water_powered_lift

